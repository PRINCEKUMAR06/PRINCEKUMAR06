
import React, { useState } from 'react';
import axios from 'axios';
import WeatherCard from './components/WeatherCard';

const App = () => {
  const [city, setCity] = useState("Delhi");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");

  const fetchWeather = async () => {
    try {
      setError("");
      const res = await axios.get(`https://weather-mcp-prince.onrender.com/weather?city=${city}`);
      setWeather(res.data);
    } catch (err) {
      setError("Weather data not found!");
      setWeather(null);
    }
  };

  return (
    <div className="min-h-screen bg-blue-100 p-4 flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-4">Weather App</h1>
      <input
        type="text"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        className="p-2 border rounded w-60 mb-2"
        placeholder="Enter city name"
      />
      <button onClick={fetchWeather} className="bg-blue-500 text-white px-4 py-2 rounded">
        Get Weather
      </button>

      {error && <p className="text-red-500 mt-4">{error}</p>}
      {weather && <WeatherCard weather={weather} />}
    </div>
  );
};

export default App;
