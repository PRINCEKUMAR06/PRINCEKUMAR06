
import React from 'react';

const WeatherCard = ({ weather }) => {
  return (
    <div className="mt-6 bg-white p-4 rounded shadow-md w-80 text-center">
      <h2 className="text-xl font-semibold">{weather.name}</h2>
      <p className="text-gray-700 text-lg">{weather.main.temp} °C</p>
      <p className="text-gray-600 italic">{weather.weather[0].description}</p>
    </div>
  );
};

export default WeatherCard;
