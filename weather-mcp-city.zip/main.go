
package main

import (
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "os"
)

var apiKey = os.Getenv("OPENWEATHER_API_KEY")

type WeatherResponse struct {
    Name string `json:"name"`
    Main struct {
        Temp float64 `json:"temp"`
    } `json:"main"`
    Weather []struct {
        Description string `json:"description"`
    } `json:"weather"`
}

func getWeatherHandler(w http.ResponseWriter, r *http.Request) {
    city := r.URL.Query().Get("city")
    if city == "" {
        city = "Delhi" // default
    }

    apiURL := fmt.Sprintf("https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric", city, apiKey)

    resp, err := http.Get(apiURL)
    if err != nil || resp.StatusCode != 200 {
        http.Error(w, "Failed to fetch weather data", http.StatusInternalServerError)
        return
    }
    defer resp.Body.Close()

    var data WeatherResponse
    err = json.NewDecoder(resp.Body).Decode(&data)
    if err != nil {
        http.Error(w, "Error parsing weather data", http.StatusInternalServerError)
        return
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(data)
}

func main() {
    http.HandleFunc("/weather", getWeatherHandler)
    log.Println("Server running on http://localhost:8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}
