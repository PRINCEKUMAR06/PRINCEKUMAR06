
# Weather MCP Server (City-Based Query)

A lightweight Go server that fetches real-time weather data for any city using the OpenWeatherMap API. It supports city-based weather queries and returns temperature and condition information.

## Features

- Query weather by city name
- Real-time weather data using OpenWeatherMap API
- JSON response format
- Easy to deploy with Docker

## API Endpoint

```
GET /weather?city=CityName
```

**Example:**
```
http://localhost:8080/weather?city=London
```

## Setup Instructions

### 1. Clone the Repository
```bash
git clone https://github.com/PRINCEKUMAR06/weather-mcp-server-city.git
cd weather-mcp-server-city
```

### 2. Set Environment Variable
```bash
export OPENWEATHER_API_KEY=your_api_key_here
```

### 3. Run the Server
```bash
go run main.go
```

### 4. Docker Setup

#### Build and Run using Docker:
```bash
docker build -t weather-mcp .
docker run -p 8080:8080 -e OPENWEATHER_API_KEY=your_api_key_here weather-mcp
```

## Sample Response
```json
{
  "name": "London",
  "main": {
    "temp": 15.32
  },
  "weather": [
    {
      "description": "clear sky"
    }
  ]
}
```

## License
MIT
